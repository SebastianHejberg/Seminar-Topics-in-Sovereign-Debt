clear all
addpath('tools')
addpath('results')
warning off;
per     = 4;    % 4 years
cas_    = 1; % 1 -> max(primary surplus), 0 -> max(rev)-min(exp)
nr      = 11;
mth     = 0;    % 1 -> Rouwenhorst, 0 -> Tauchen-Hussey
rbar    = 0.153266526566756;
rhor    = 0.943091135803343;
ser     = 0.038280068006970;
[r,P]   = build_markov_chain(rbar,rhor,ser,nr,mth);
rd      = [
    % 1980-2010
    0.161484952493892
    0.260493856538076
    0.305106392560901
    0.282126123521423
    0.341963898562945
    0.282877693222967
    0.199588520450488
    0.204361053535527
    0.209823126533438
    0.200886682877272
    0.193575962170116
    0.164280154107479
    0.152552488378052
    0.116576194070290
    0.179305124806435
    0.168090685584151
    0.165563605450087
    0.171047184372016
    0.148149283027075
    0.153751352302321
    0.157308189565951
    0.092551718880860
    0.082283366891573
    0.034551246002300
    0.031703736581940
    0.041359219817951
    0.071624437592719
    0.068682915999450
    0.024417803081087
    0.040378571100200
    0.015944951581579
    ];
load pd_iid.mat DATA resm
DIID=DATA;
RIID=resm;
load calibgengov;
switch cas_
    case 1
        XX  = ALP1;
    otherwise
        XX  = ALP2;
end
cas_    = 1; % 1 -> max(primary surplus), 2 -> max(rev)-min(exp), 3-> mean

ncount  = length(ALP1);
XX      = [repmat([0.04 0.045 0.05],ncount,1) ALP1];
str     = [];
Bm      = zeros(nr,ncount);
Dm      = zeros(nr,ncount);
Fm      = zeros(nr,ncount);
xb      = repmat([0 1],ncount,1);
rng('default');
rs      = filter(1,[1 -rhor],ser*randn(100000,1))+rbar;

k       = 1;
tmpm    = zeros(ncount,3);
resm    = [];
DATA    = cell(ncount,1);
T0=1980;
T1=2010;
for icount=1:ncount
    DATA{icount}=[(T0:T1)' BSY(11:end,icount)];
end
opts=optimset('Display','off','MaxFunEvals',1e9,'MaxIter',1e9);
for j=3
    for icount=[7 9];1:ncount
        fprintf('%2d/%2d: %s\n',icount,ncount,Namc{icount})
        alpha   = XX(icount,j);
        seg     = SY(icount);
        gbar1   = log(1+MDY(icount));
        gbar    = per*gbar1;
        %% main loop
        d       = zeros(nr,1);
        b       = 0.2*ones(nr,1);
        x0      = ones(nr,1);
        b0      = b;
        crit    = 1;
        tol     = 1e-6;
        while crit>tol
            for i=1:nr
                p       = P(i,:);
                ri      = r(i);
                param   = [alpha gbar seg ri];
                [x,f]   = fminunc(@intrate_iid,-5,opts,param,p,b0);
                b(i)    =-f;
                d(i)    = exp(x);
            end
            crit= max(abs(b0-b));
            fprintf('%12.8f\n',crit)
            b0  = b;
        end
        Bm(:,icount)= b;
        Dm(:,icount)= d;
        z           = (log(d./(alpha+b))-gbar)/seg;
        Fm(:,icount)= 1-(1-(1+erf(z/sqrt(2)))/2).^(1/per);
        EDm         = interp1(r,Dm(:,icount),rd,'cubic');
        EBm         = interp1(r,Bm(:,icount),rd,'cubic');
        Ezm         = (log(EDm./(alpha+EBm))-gbar)/seg;
        EFm         = 1-(1-(1+erf(Ezm/sqrt(2)))/2).^(1/per);
        Ez          = (log(0.01*(BSY(11:end,icount)/per)./(alpha+EBm))-gbar)/seg;
        EFd         = 1-(1-(1+erf(Ez/sqrt(2)))/2).^(1/per);
        DATA{icount}= [DATA{icount} 100*per*EDm 100*EFd(:)];
        
        
    end
end
%%
fs=12;
subplot(221);h=plot(r,per*100*Bm(:,[7 9]));
set(h(2),'color','k','linewidth',2)
set(h(1),'color','k','linewidth',2,'linestyle','--')
set(gca,'fontname','times','fontsize',fs,'xlim',r([1 end]),'ylim',[40 140]);
xlabel('Real Interest Rate','fontname','times','fontsize',fs);
title('b_M','fontname','times','fontsize',fs);
legend('France','Greece','location','northeast')
grid on;
subplot(222);h=plot(r,per*100*Dm(:,[7 9]));
set(h(2),'color','k','linewidth',2)
set(h(1),'color','k','linewidth',2,'linestyle','--')
set(gca,'fontname','times','fontsize',fs,'xlim',r([1 end]),'ylim',[40 140]);
xlabel('Real Interest Rate','fontname','times','fontsize',fs);
title('d_M','fontname','times','fontsize',fs);
grid on;
pause
print('-depsc2','decrules_r')
close
