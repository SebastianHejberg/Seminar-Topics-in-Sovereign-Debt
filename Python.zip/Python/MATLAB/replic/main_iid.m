clear all
addpath('tools')
load calibgengov;
per     = 4;    % 4 years
r       = 0.152335822311631; % 1980-2010
cas_    = 1; % 1 -> max(primary surplus), 2 -> max(rev)-min(exp), 3-> mean

ncount  = length(ALP1);
XX      = [repmat([0.04 0.045 0.05],ncount,1) ALP1];
resd    = zeros(ncount,4);
tmpm    = zeros(ncount,3);
tmpb    = zeros(ncount,3);
resm    = [];
resb    = [];
str     = [];
Gs1     =-1;
T0      = 1980;
T1      = 2010;
TT1     = 1965:2011;
smpl1   = find(TT1==1980):find(TT1==2010);
TT2     = 1970:2011;
smpl2   = find(TT2==1980):find(TT2==2010);
DATA    = cell(ncount,1);
Fm      = cell(ncount,1);
Laffer  = cell(ncount,1);
for icount=1:ncount
    DATA{icount}=[];
    Fm{icount}=[];
    Laffer{icount}=[];
end

for iexp=1:4;    
    ALP1    = XX(:,iexp);
    for icount=1:ncount
        alpha   = ALP1(icount);%4{icount}(end);
        seg     = SY(icount);
        gbar1   = log(1+MDY(icount));
        gbar    = per*gbar1;
        
        %% main loop
        Gs1     = fcsolve(@solve_iid,Gs1,[],seg); % (Works well in the iid case)
        F1      = (1+erf(Gs1/sqrt(2)))/2;
        EBn     = alpha*exp(gbar+seg*Gs1)*(1-F1)/(1+r);
        EBe     = alpha*exp(gbar+seg*seg/2)/(1+r-exp(gbar+seg*seg/2));
        if EBe<0;EBe=inf;end
        EBm     = alpha*exp(gbar+seg*Gs1)*(1-F1)/(1+r-exp(gbar+seg*Gs1)*(1-F1));
        EDm     = exp(gbar+seg*Gs1)*(alpha+EBm);
        Ez      = (log(EDm./(alpha+EBm))-gbar)/seg;
        EFm     = 1-(1-(1+erf(Ez/sqrt(2)))/2)^(1/per);
        
%         Ez      = (log(0.01*BSY(end,icount)./(alpha+per*EBm))-gbar1)/(seg/per);
        Ez      = (log(0.01*(BSY(end,icount)/per)./(alpha+EBm))-gbar)/(seg);
        if imag(Ez)==0
            EFd     = 1-(1-(1+erf(Ez/sqrt(2)))/2)^(1/per);
        else
            EFd=NaN;
        end        
        resd(icount,:)  = [100*alpha 100*gbar/4 100*SY(icount) BSY(end,icount)];
        tmpm(icount,:)  = [100*per*EDm 100*EFm 100*EFd];
        tmpb(icount,:)  = [100*per*EBn 100*per*EBm 100*per*EBe];
        D       = linspace(0.8*EDm,1.8*EDm,1000)';
%         Ez      = (log(per*D./(alpha+per*EBm))-gbar1)/(seg/per);
        Ez      = (log(D./(alpha+EBm))-gbar)/(seg);
        Fm{icount} = [Fm{icount} per*D 1-(1-(1+erf(Ez/sqrt(2)))/2).^(1/per)];%^(1/per);
        Laffer{icount} = [Laffer{icount} D.*(1-(1-(1+erf(Ez/sqrt(2)))/2))/(1+r)];%^(1/per);
        
        
        ALP     = alpha*(smpl1>0);
        BSYobs  = 0.01*BSY(smpl2,icount)/per;
        seg     = SY(icount);
        gbar1   = log(1+MDY(icount));
        gbar    = per*gbar1;
        Gs1     = fcsolve(@solve_iid,Gs1,[],seg); % (Works well in the iid case)
        F1      = (1+erf(Gs1/sqrt(2)))/2;
        EFd     = zeros(length(smpl1),1);
        for t=1:length(smpl1);
            EBm(t)     = ALP(t)*exp(gbar+seg*Gs1)*(1-F1)/(1+r-exp(gbar+seg*Gs1)*(1-F1));
%             Ez      = (log(BSYobs(t)./(ALP(t)+per*EBm(t)))-gbar1)/(seg/per);
            Ez      = (log(BSYobs(t)./(ALP(t)+EBm(t)))-gbar)/(seg);
            if imag(Ez)==0
                EFd(t)  = 1-(1-(1+erf(Ez/sqrt(2)))/2).^(1/per);
            else
                EFd(t)=NaN;
            end
        end
        DATA{icount}=[DATA{icount} (T0:T1)' 100*per*(BSYobs(:)-EDm) 100*EFd(:)];
        
    end
    resm=[resm tmpm]; % contains the maximum sustainable debt and the probability of default in the iid case
    resb=[resb tmpb]; % contains the maximum static borrowing, maximum sustainable borrowing and equity like measure
end
% save pd_iid.mat DATA resm resb

%%
for i=1:ncount
    fprintf('%15s & %6.2f & %6.2f & %6.2f & %6.2f \\\\ \n',Namc{i},resd(i,:))
end
%%
disp(' ')
fmt = ['%15s ' repmat('& %6.2f & %6.2f & %6.2f ',1,size(XX,2)) ,'\\\\ \n'];
for i=1:ncount
    fprintf(fmt,Namc{i},resm(i,:))
end
%%
disp(' ')
fmt = ['%15s ' repmat('& %6.2f & %6.2f & %6.2f ',1,size(XX,2)) ,'\\\\ \n'];
for i=1:ncount
    fprintf(fmt,Namc{i},resb(i,:))
end
return
%%
for icount=1:23;
    figure(1);set(gcf,'name',Namc{icount})
    subplot(221);h=plot(DATA{icount}(:,1),[DATA{icount}(:,2) repmat(resm(icount,1:3:10),length(T0:T1),1)]);
    title('Debt vs D_M','fontname','times','fontsize',12);
    set(gca,'fontname','times','fontsize',12,'xlim',[T0 T1]);
    set(h(1),'color','k','linewidth',1.5)
    set(h(2),'color','k','linewidth',1)   
    set(h(3),'color','k','linewidth',1,'linestyle','--')
    set(h(4),'color','r','linewidth',1)
    set(h(5),'color','r','linewidth',1,'linestyle','--')

    subplot(222);h=plot(DATA{icount}(:,1),DATA{icount}(:,3:3:end));
    title('Default Probability','fontname','times','fontsize',12);
    set(gca,'fontname','times','fontsize',12,'xlim',[T0 T1],'ylim',[-5 105])
    set(h(1),'color','k','linewidth',1)
    set(h(2),'color','k','linewidth',1,'linestyle','--')
    set(h(3),'color','r','linewidth',1)
    set(h(4),'color','r','linewidth',1,'linestyle','--')
    pause
%     printpdf(['debt_prob_iidgengov_',Filec{icount}]);
    close
end
%%
X1  = 100*Fm{7}(:,5);
Y1  = Fm{7}(:,6);
X2  = 100*Fm{9}(:,5);
Y2  = Fm{9}(:,6);
h=plot(X1,Y1,X2,Y2);
set(gca,'fontname','times','fontsize',16)
set(h(2),'color','k','linewidth',1.2)
set(h(1),'color','k','linewidth',1.2,'linestyle','--')
xlabel('d','fontname','times','fontsize',16)
o=legend('France','Greece','location','northeast')
set(o,'fontname','times','fontsize',20)
grid on;
pause
printpdf('Distrib');
matlab2tikz('distrib.tikz')
close
%%
for icount=1:23;
    h=plot(100*Fm{icount}(:,1:2:7),Fm{icount}(:,2:2:8));
    set(gca,'fontname','times','fontsize',12)
    set(h(1),'color','k','linewidth',1)
    set(h(2),'color','k','linewidth',1,'linestyle','--')
    set(h(3),'color','r','linewidth',1)
    set(h(4),'color','r','linewidth',1,'linestyle','--')
%     pause
    printpdf(['distrib_iidgengov_',Filec{icount}]);
    close
end

%%
for icount=1:23;
    fprintf('%15s \\\\ \n',Namc{icount})
    fprintf('\\includegraphics[width=0.65\\textwidth]{debt_prob_iidgengov_%s} \\\\ \n',Filec{icount})
end
%%
for icount=1:23;
    fprintf('%15s \\\\ \n',Namc{icount})
    fprintf('\\includegraphics[width=0.65\\textwidth]{distrib_iidgengov_%s} \\\\ \n',Filec{icount})
end


return
%%
str={'\alpha (in percent)','\sigma','\mu (in percent/year)'};
fstr={'alpha','sigma','mu'};
typstr='dm';
ind_    = 5;    % 4->bm, 5->dm

for id=1:3
    h=plot(res(:,id),res(:,ind_),'o');
    set(h,'marker','none');
    hold on;
    for i=1:ncount;
        text(res(i,id),res(i,ind_),upper(Filec{i}),'fontname','times','fontsize',8);
    end
    xlabel(str{id},'fontname','times','fontsize',16)
    rols=ols(res(:,ind_),[ones(ncount,1) res(:,id)]);
    xlim=get(gca,'xlim');
    ylim=rols.beta(1)+xlim*rols.beta(2);
    h=line(xlim,ylim);
    set(h,'color','r','linewidth',2)
    set(gca,'fontname','times','fontsize',16)
    printpdf(strcat(fstr{id},'_',typstr));
    close
end
% plot(res(:,3),res(:,4),'.');hold on;for i=1:ncount;text(res(i,3),res(i,4),Filec{i},'fontname','times','fontsize',16);end
% plot(res(:,3),res(:,4),'.');hold on;for i=1:ncount;text(res(i,3),res(i,4),Filec{i},'fontname','times','fontsize',16);end


