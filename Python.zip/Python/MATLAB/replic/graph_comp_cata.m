clear all
addpath('results')
load calib;
Namc{23}='United States';
load pd_iid
Diid=DATA;
load pd_cata
Dcat=DATA;
T0=1980;
T1=2010;
close all
k=1;
j=1;
sel=[3 4 9 10 11 12 13 18 23];
for i=1:length(sel);
    subplot(3,3,i)
    h=plot(Diid{sel(i)}(:,1),[Diid{sel(i)}(:,9) Dcat{sel(i)}(:,3)]);
    set(gca,'fontname','times','fontsize',12,'xlim',[T0 T1],'ylim',[-5 105])
    set(h(1),'color','k','linewidth',1,'linestyle','--')
    set(h(2),'color','k','linewidth',1)
    title(Namc{sel(i)},'fontname','times','fontsize',12);
end
print('-depsc2','proba_cata');
