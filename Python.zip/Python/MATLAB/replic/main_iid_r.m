clear all
addpath('tools')
per     = 4;    % 4 years
cas_    = 1; % 1 -> max(primary surplus), 0 -> max(rev)-min(exp)
nr      = 11;
mth     = 0;    % 1 -> Rouwenhorst, 0 -> Tauchen-Hussey
rbar    = 0.153266526566756;
rhor    = 0.943091135803343;
ser     = 0.038280068006970;
[r,P]   = build_markov_chain(rbar,rhor,ser,nr,mth);
rd      = [
    % 1980-2010
    0.161484952493892
    0.260493856538076
    0.305106392560901
    0.282126123521423
    0.341963898562945
    0.282877693222967
    0.199588520450488
    0.204361053535527
    0.209823126533438
    0.200886682877272
    0.193575962170116
    0.164280154107479
    0.152552488378052
    0.116576194070290
    0.179305124806435
    0.168090685584151
    0.165563605450087
    0.171047184372016
    0.148149283027075
    0.153751352302321
    0.157308189565951
    0.092551718880860
    0.082283366891573
    0.034551246002300
    0.031703736581940
    0.041359219817951
    0.071624437592719
    0.068682915999450
    0.024417803081087
    0.040378571100200
    0.015944951581579
    ];
r2010   = rd(end);
load calibgengov;
switch cas_
    case 1
        XX  = ALP1;
    otherwise
        XX  = ALP2;
end

ncount  = length(ALP1);
XX      = [repmat([0.04 0.045 0.05],ncount,1) ALP1];
str     = [];
Bm      = zeros(nr,ncount);
Dm      = zeros(nr,ncount);
Fm      = zeros(nr,ncount);
xb      = repmat([0 1],ncount,1);
rng('default');
rs      = r2010;
k       = 1;
tmpm    = zeros(ncount,3);
resm    = [];
DATA    = cell(ncount,1);
for icount=1:ncount
    DATA{icount}=[];
end
T0=1980;
T1=2010;
% opts=optimset('Display','off','MaxFunEvals',1e9,'MaxIter',1e9);
method='linear';
for j=3; 
    for icount=1:ncount
        fprintf('%2d/%2d: %s\n',icount,ncount,Namc{icount})
        alpha   = XX(icount,j);
        seg     = SY(icount);
        gbar1   = log(1+MDY(icount));
        gbar    = per*gbar1;
        %% main loop
        d       = zeros(nr,1);
        b       = 0.2*ones(nr,1);
        x0      = ones(nr,1);
        b0      = b;
        crit    = 1;
        tol     = 1e-6;
        while crit>tol
            for i=1:nr
                p       = P(i,:);
                ri      = r(i);
                param   = [alpha gbar seg ri];
                %                 [x,f]   = fminbnd(@intrate_iid,xb(icount,1),xb(icount,2),[],param,p,b0);
                [x,f]   = fminbnd(@intrate_iid,-10,0,[],param,p,b0);
%                                 [x,f]   = fminunc(@intrate_iid,-5,opts,param,p,b0);
                b(i)    =-f;
                d(i)    = exp(x);
            end
            %             b1=0.85*b0+0.15*b;
            crit= max(abs(b0-b));
            fprintf('%12.8f\n',crit)
            b0  = b;
        end
        Bm(:,icount)    = b;
        Dm(:,icount)    = d;
        z               = (log(d./(alpha+b))-gbar)/seg;
        Fm(:,icount)    = 1-(1-(1+erf(z/sqrt(2)))/2).^(1/per);
        
        EDm = interp1(r,Dm(:,icount),r2010,method);
        EBm = interp1(r,Bm(:,icount),r2010,method);
        Ezm = (log(EDm./(alpha+EBm))-gbar)/seg;
        EFm = 1-(1-(1+erf(Ezm/sqrt(2)))/2).^(1/per);
        
        Ezd = (log(0.01*(BSY(end,icount)/per)./(alpha+EBm))-gbar)/seg;
        EFd = 1-(1-(1+erf(Ezd/sqrt(2)))/2).^(1/per);
        tmpm(icount,:)  = [100*per*EDm 100*EFm 100*EFd];
        
        res = [100*XX(icount,j) 100*SE(icount) 100*MDY(icount) 100*per*mean(EBm) 100*per*mean(EDm) 100*mean(EFm) BSY(end,icount) 100*EFd];
        fstr= sprintf('%15s & %6.2f & %6.2f & %6.2f & %6.2f & %6.2f & %6.2f & %6.2f & %6.2f \\\\',Namc{icount},res);
        str = strvcat(str,fstr);
        
        seg     = SY(icount);
        gbar    = per*log(1+MDY(icount));
        EBm     = interp1(r,Bm(:,icount),rd(1:end),method);
        Ez      = (log(0.01*(BSY(11:end,icount)/per)./(alpha+EBm))-gbar)/seg;
        EFd     = 1-(1-(1+erf(Ez/sqrt(2)))/2).^(1/per);
        EDm     = interp1(r,Dm(:,icount),rd(1:end),method);
        DATA{icount}=[DATA{icount} (T0:T1)' 400*EDm 100*BSY(11:end,icount) 100*EFd(:)];
%         DATA{icount}=[DATA{icount} (T0:T1)' 100*(BSY(11:end,icount)-4*EDm) 100*EFd(:) 100*BSY(11:end,icount)];
        
        
    end
    resm=[resm tmpm];
    
end
% return
%%
fmt = ['%15s ' repmat('& %6.2f & %6.2f & %6.2f ',1,size(XX,2)) ,'\\\\ \n'];
fmt = ['%15s ' repmat('& %6.2f & %6.2f & %6.2f ',1,1) ,'\\\\ \n'];
for i=1:ncount
    fprintf(fmt,Namc{i},resm(i,:))
end
return
%%
save pd_iidr.mat DATA resm