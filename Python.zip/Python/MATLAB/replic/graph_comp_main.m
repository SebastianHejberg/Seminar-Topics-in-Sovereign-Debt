clear all
load calibgengov;
Namc{23}='United States';
selc=[3 7 9 10 11 12 13 18];
load pd_iid
Diid=DATA;
Riid=resm;
load pd_iidrecov
Drec=DATA;
Rrec=resm;
load pd_iidr
Dr=DATA;
T0=1980;
T1=2010;
T   = T1-T0+1;
str={'040','045','050','mps'};
close all
k=1;
j=1;
for icount=selc;
    subplot(2,2,1)
    h=plot(Diid{icount}(:,1),[Diid{icount}(:,2) kron([Riid(icount,7) Riid(icount,1) Riid(icount,10)],ones(T,1))  Dr{icount}(:,2)]);
    set(gca,'fontname','times','fontsize',12,'xlim',[T0 T1])
    set(h(1),'color','b','linewidth',1.5)
    set(h(2),'color','k','linewidth',1)
    set(h(3),'color','k','linewidth',1,'linestyle','--')
    set(h(4),'color','r','linewidth',1)
    set(h(5),'color','r','linewidth',1,'linestyle','--')
    title('Actual Debt vs d_M','fontname','times','fontsize',12)
    subplot(2,2,2)
    h=plot(Diid{icount}(:,1),[Diid{icount}(:,9) Diid{icount}(:,3) Diid{icount}(:,12) Dr{icount}(:,4)]);
    set(gca,'fontname','times','fontsize',12,'xlim',[T0 T1],'ylim',[-5 105])
    set(h(1),'color','k','linewidth',1)
    set(h(2),'color','k','linewidth',1,'linestyle','--')
    set(h(3),'color','r','linewidth',1)
    set(h(4),'color','r','linewidth',1,'linestyle','--')
    title('Default Probability','fontname','times','fontsize',12)
    pause
    matlab2tikz(strcat('debt_prob_',Namc{icount}))
    close
end