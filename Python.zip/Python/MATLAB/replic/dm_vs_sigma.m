clear all
load calib;
per     = 4;    % 4 years
r       = 0.152335822311631;%0.054592809226178;
cas_    = 1; % 1 -> max(primary surplus), 2 -> max(rev)-min(exp), 3-> mean

ncount  = length(ALP1);
XX      = [repmat([0.04 0.045 0.05],ncount,1) ALP1];
resd    = zeros(ncount,4);
tmpm    = zeros(ncount,3);
resm    = [];
str     = [];
Gs1     =-1;
T0      = 1980;
T1      = 2010;
TT1     = 1965:2011;
smpl1   = find(TT1==1980):find(TT1==2010);
TT2     = 1970:2011;
smpl2   = find(TT2==1980):find(TT2==2010);
DATA    = cell(ncount,1);
Fm      = cell(ncount,1);
for icount=1:ncount
    DATA{icount}=[];
    Fm{icount}=[];
end
ALP1    = 0.05;
for icount=9;
    alpha   = 0.05;
    seg     = SY(icount);
    gbar1   = log(1+MDY(icount));
    gbar    = per*gbar1;
    ns      = 100;
    SS      = linspace(0.1*seg,5*seg,ns);
    EDm     = zeros(ns,1);
    for i=1:ns
        seg     = SS(i);
        Gs1     = fcsolve(@solve_iid,Gs1,[],seg); % (W  orks well in the iid case)
        F1      = (1+erf(Gs1/sqrt(2)))/2;
        EBm     = alpha*exp(gbar+seg*Gs1)*(1-F1)/(1+r-exp(gbar+seg*Gs1)*(1-F1));
        EBe(i)     = alpha/((1+r)/exp(gbar+seg^2/2)-1);
        EDm(i)     = exp(gbar+seg*Gs1)*(alpha+EBm);
    end
end
%%
plot(SS,100*per*EDm,'k-','linewidth',2);
set(gca,'fontname','times','fontsize',16);
xlabel('$\sigma$','fontname','times','fontsize',16,'interpreter','latex');
ylabel('$d_M$','fontname','times','fontsize',16,'interpreter','latex');
grid
print('-depsc2','Dm_seg');
