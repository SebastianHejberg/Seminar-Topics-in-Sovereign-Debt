clear all
whole=1965:2012;
T0  = 1965;
T1  = 2011;
smpl= find(whole==T0):find(whole==T1);
Nam0= {'Australia','Austria','Belgium','Canada','Czech Republic',...
    'Denmark','Estonia','Finland','France','Germany','Greece',...
    'Hungary','Iceland','Ireland','Israel','Italy','Korea',...
    'Luxembourg','Netherlands','New Zealand','Norway','Poland',...
    'Portugal','Slovak Republic','Slovenia','Spain','Sweden',...
    'Switzerland','United Kingdom','United States'};
File0={'aus','aut','be','can','cze','dnk','est','fin','fr','deu','gr',...
    'hng','ice','ire','isr','ita','kor','lux','nld','nzl','nor','pol',...
    'prt','slv','sln','esp','swe','ch','uk','us'};
selc= [1:4 6 8:14 16:17 19:21 23 26:30];
n   = length(selc);
Namc= cell(n,1);
Filec= cell(n,1);
for i=1:n
    Namc{i}=Nam0{selc(i)};
    Filec{i}=File0{selc(i)};
end
%%

datT= dlmread('data/total_gov_revenue.csv',';',1,1);
datT= datT(smpl,selc);
datG= dlmread('data/total_gov_exp.csv',';',1,1);
datG= datG(smpl,selc);
datY= dlmread('data/gdp.csv',';',1,1);
datY= datY(smpl,selc);
daty= dlmread('data/gdp_per_capita.csv',';',1,1);
daty= daty(smpl,selc);

datI= dlmread('data/interests.csv',';',1,1);
datI= datI(smpl,selc);

datGS= dlmread('data/gross_savings.csv',';',1,1);
datGS= datGS(smpl,selc);

datNS= dlmread('data/net_savings.csv',';',1,1);
datNS= datNS(smpl,selc);
%datBY= csvread('data/debt_gdp_ratio.csv',1,1);
datBY= csvread('data/dsy_gengov.csv',1,1);
D=datBY(datBY(:,1)<=2010,:).*daty(7:47,:);
plot(D(1:end-1,:)./daty(7:46,:),D(2:end,:)./daty(7:46,:),'o')

%%
n   = size(datT,2);
ALP1= zeros(n,1);
ALP2= zeros(n,1);
ALP3= zeros(n,1);
MDY = zeros(n,1);
RHO = zeros(n,1);
SE  = zeros(n,1);
SY  = zeros(n,1);
BSY = zeros(41,n);
DY  = zeros(46,n);
per = 4;
N   = 100000;
e   = randn(per*N,1);
mt=0;
for i=1:n
    tsy     = datT(:,i)./datY(:,i);
    gsy     = (datG(:,i)-datI(:,i))./datY(:,i);
    dsy     = tsy-gsy;
    T       = length(dsy);
    ismpl   = whole(~isnan(dsy));
    dsy     = dsy(~isnan(dsy));
    
    smpl    = whole(~isnan(dsy));
    tsy=tsy(~isnan(tsy));
    mt=mt+mean(tsy)/n;
    gsy=gsy(~isnan(gsy));    
    ALP1(i) = max(dsy);                 % maximum primary surplus
    ALP2(i) = max(tsy(~isnan(tsy)))-min(gsy(~isnan(gsy)));                  % max revenue-min exp.
    ALP3(i) = mean(dsy(~isnan(dsy)));                  % max revenue-min exp.

    ly      = log(daty(~isnan(daty(:,i)),i));
    dY      = ly(2:end)-ly(1:end-1);
    res     = est_ar(dY,1);
    resagg  = res;
    MDY(i)  = mean(dY);
    RHO(i)  = resagg.beta(2);
    SE(i)   = std(resagg.resid);
    % for iid case
    x       = std(res.resid)*e;
    x       = sum(reshape(x,per,N))';
    SY(i)   = std(x);
    BSY(:,i)= datBY(:,i);
    DY(:,i) = log(daty(2:end,i))-log(daty(1:end-1,i));
end
DY  = DY(1:end-1,:);
save('calibgengov','Namc','Filec','ALP1','ALP2','ALP3','MDY','SY','RHO','SE','BSY','DY');