function P=rouwenhorst(n,p,varargin)

if nargin>2
    q   = varargin{1};
else
    q   = p;
end

P   = [p 1-p;1-q q];
if n>2
    for j   = 3:n
        z0          = zeros(j-1,1);
        P           = p*[P z0;z0' 0]+(1-p)*[z0 P;0 z0']+(1-p)*[z0' 0;P z0]+q*[0 z0';z0 P];
        P(2:j-1,:)  = P(2:j-1,:)/2;
    end
    
end