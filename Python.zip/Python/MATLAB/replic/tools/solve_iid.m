function res=solve_iid(z,sigma)

cdf = (1+erf(z/sqrt(2)))/2;
pdf = exp(-z*z/2)/sqrt(2*pi);
res = sigma*(1-cdf)-pdf;