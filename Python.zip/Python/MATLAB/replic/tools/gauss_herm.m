function [x,w,int]=gauss_herm(n,f,varargin)
%
% Compute the coefficients of Hermite polynomials using the recursion
%
% H(n+1)=2H(n)-2nH(n-1)
%
p(1,1)=1;
p(2,1:2)=[2 0];
for k=2:n
   p(k+1,1:k+1)=2*[p(k,1:k) 0]-2*(k-1)*[0 0 p(k-1,1:k-1)];
end
%
% Compute the roots
%
x	= sort(roots(p(n+1,:)));
%
% Coefficients
%
w   = zeros(n,1);
for i=1:n
   w(i)=(2.^(n-1)*(factorial(n)).*sqrt(pi))./(n.^2.*(polyval(p(n,1:n),x(i))).^2);
end

if nargin>1;
   int=w'*feval(f,x,varargin{:});
end
