function res=solve_recov_iid(z,sigma,alpha,bm)

cdf = (1+erf(z/sqrt(2)))/2;
pdf = exp(-z*z/2)/sqrt(2*pi);
res = (alpha+bm)*sigma*(1-cdf)-bm*pdf;