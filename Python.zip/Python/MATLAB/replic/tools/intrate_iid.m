function res=intrate_iid(d,param,p,b)

alpha   = param(1);
gbar    = param(2);
seg     = param(3);
r       = param(4);
d       = exp(d);
z       = (log(d)-log(alpha+b)-gbar)/seg;
F       = (1+erf(z/sqrt(2)))/2;

res     = d*(p*(1-F))/(1+r);
res     =-res;