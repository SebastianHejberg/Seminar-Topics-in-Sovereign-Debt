clear all
% produces figures 2 and 4
addpath('tools')
addpath('results')
load calibgengov;
per     = 4;    % 4 years
r       = 0.152335822311631; % 1980-2010
cas_    = 1; % 1 -> max(primary surplus), 2 -> max(rev)-min(exp), 3-> mean

ncount  = length(ALP1);
XX      = [repmat([0.04 0.045 0.05],ncount,1) ALP1];
resd    = zeros(ncount,4);
tmpm    = zeros(ncount,3);
tmpb    = zeros(ncount,3);
resm    = [];
resb    = [];
str     = [];
Gs1     =-1;
T0      = 1980;
T1      = 2010;
TT1     = 1965:2011;
smpl1   = find(TT1==1980):find(TT1==2010);
TT2     = 1970:2011;
smpl2   = find(TT2==1980):find(TT2==2010);
nd      = 1000;
D       = linspace(0,0.5,nd)';
LAFFER  = zeros(nd,ncount);
Rd      = zeros(nd,ncount);
Rpd     = zeros(nd,ncount);
for icount=[7 9]
    alpha   = 0.05;
    seg     = SY(icount);
    gbar1   = log(1+MDY(icount));
    gbar    = per*gbar1;
    
    Gs1     = fcsolve(@solve_iid,Gs1,[],seg); % (W  orks well in the iid case)
    F1      = (1+erf(Gs1/sqrt(2)))/2;
    Bm      = alpha*exp(gbar+seg*Gs1)*(1-F1)/(1+r-exp(gbar+seg*Gs1)*(1-F1));
    Dm(icount)      = exp(gbar+seg*Gs1)*(alpha+Bm);
    zm      = (log(Dm(icount)./(alpha+Bm))-gbar)/seg;
    Fm      = (1+erf(zm/sqrt(2)))/2;
    Rdm(icount)     = (1+r)/(1-Fm);
    z       = (log(D./(alpha+Bm))-gbar)/seg;
    cdf     = (1+erf(z/sqrt(2)))/2;
    pdf     = exp(-z.*z/2)/sqrt(2*pi);
    CDF(:,icount)   = cdf;
    Rd(:,icount)    = (1+r)./(1-cdf);
    Rpd(:,icount)   = (1+r)*pdf./(seg*(1-cdf).*(1-cdf).*D);
    LAFFER(:,icount)= (1-cdf).*D/(1+r);
end
%%
h=plot(100*per*D,100*per*LAFFER(:,[7 9]));
set(h(1),'color','k','linewidth',2,'linestyle','--')
set(h(2),'color','k','linewidth',2,'linestyle','-')
xlabel('d_t','fontname','times','fontsize',20)
set(gca,'fontname','times','fontsize',16)
grid on
legend('France','Greece','location','northwest')
pause
print('-depsc2','laffer_curve');
close
%%
h=plot(100*per*D,1-(1-CDF(:,[7 9])).^(1/per));
set(h(1),'color','k','linewidth',2,'linestyle','--')
set(h(2),'color','k','linewidth',2,'linestyle','-')
xlabel('d_t','fontname','times','fontsize',20)
set(gca,'fontname','times','fontsize',16,'xlim',[60 260])
grid on
legend('France','Greece','location','northwest')
pause
print('-depsc2','cdf');
close
%%
smpl1=find(and(D>0.3,D<0.4));
smpl2=find(and(D>0.3,D<0.375));

icount=7;
subplot(221);
h=plot(per*100*D(smpl1),Rd(smpl1,icount)./D(smpl1),per*100*D(smpl2),Rpd(smpl2,icount),per*100*Dm(icount),Rdm(icount)/Dm(icount),'ko');
set(h(1),'color','k','linewidth',1.2,'linestyle','-')
set(h(2),'color',0.6*ones(1,3),'linewidth',1.2,'linestyle','-')
xlabel('d_t','fontname','times','fontsize',12)
set(gca,'fontname','times','fontsize',12)
title('France','fontname','times','fontsize',12)
grid on

smpl1=find(and(D>0.15,D<0.25));
smpl2=find(and(D>0.15,D<0.24));
icount=9;
subplot(222);
h=plot(per*100*D(smpl1),Rd(smpl1,icount)./D(smpl1),per*100*D(smpl2),Rpd(smpl2,icount),per*100*Dm(icount),Rdm(icount)/Dm(icount),'ko');
set(h(1),'color','k','linewidth',1.2,'linestyle','-')
set(h(2),'color',0.6*ones(1,3),'linewidth',1.2,'linestyle','-')
xlabel('d_t','fontname','times','fontsize',12)
set(gca,'fontname','times','fontsize',12)
title('Greece','fontname','times','fontsize',12)
grid on
pause
print('-depsc2','rdrpd');
close
